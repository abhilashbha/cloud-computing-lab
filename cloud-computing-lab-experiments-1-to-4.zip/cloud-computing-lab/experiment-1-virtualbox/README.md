# Experiment 1 – Install VirtualBox/VMware Workstation

## Aim

To install VirtualBox/VMware Workstation and set up a virtual machine with a Linux or Windows operating system.

## Procedure

1. Download and install Oracle VM VirtualBox.
2. Start VirtualBox.
3. Create or import a virtual machine.
4. Select the required operating system ISO/virtual appliance.
5. Allocate suitable memory and storage.
6. Complete the virtual machine setup.
7. Start the virtual machine and verify that the guest operating system boots.

## Lab Record

**Software:** Oracle VM VirtualBox  
**Host OS:** Windows  
**Guest OS:** Linux/Ubuntu (as used in the lab)

## Result

VirtualBox was installed and a virtual-machine environment was prepared for subsequent cloud-computing experiments.

## Evidence

Add your actual VirtualBox/Ubuntu screenshots here if available.

Suggested filenames:

- `virtualbox-installed.png`
- `vm-created.png`
- `ubuntu-running.png`
