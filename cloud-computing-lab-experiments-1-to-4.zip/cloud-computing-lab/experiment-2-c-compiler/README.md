# Experiment 2 – C Compiler in Virtual Machine

## Aim

To install/use a C compiler in the virtual machine created using VirtualBox and execute a simple C program.

## Environment

- VirtualBox
- Ubuntu virtual machine
- GCC compiler
- C language

## Procedure from the lab manual

1. Open VirtualBox.
2. Import the Ubuntu appliance (`ubuntu_gt6.ova`) if it is provided by the lab.
3. Start the Ubuntu virtual machine.
4. Open the terminal.
5. Navigate to the required working directory.
6. Create a C source file.
7. Compile it using GCC.
8. Execute the generated program.

The manual gives commands including:

```bash
cd /opt/axis2/axis2-1.7.3/bin
gedit hello.c
gcc hello.c
./a.out
```

## Program

`hello.c` contains a simple addition program.

## Result

The C program can be compiled using GCC and executed inside the Ubuntu virtual machine.

## Evidence

Add your actual terminal screenshots if available.
