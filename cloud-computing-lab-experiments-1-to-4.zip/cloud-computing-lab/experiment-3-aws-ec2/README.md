# Experiment 3 – Create an EC2 Instance in AWS

## Aim

To create an EC2 instance in Amazon Web Services (AWS).

## Procedure

1. Sign in to the AWS Management Console.
2. Open the **EC2** service.
3. Choose **Launch instance**.
4. Enter a name for the instance.
5. Select an appropriate AMI.
6. Select a suitable instance type.
7. Create/select a key pair.
8. Configure networking and storage.
9. Launch the instance.
10. Verify that the instance is running.
11. Use the AWS connection instructions to connect to the instance.

## Important Security Note

Do **not** put the following in this repository:

- `.pem` private keys
- AWS access keys
- AWS secret keys
- passwords
- session tokens
- personal credentials

The original lab manual demonstrates a free-tier-oriented EC2 setup and SSH connection workflow. Current AWS free-tier eligibility and instance options can change, so check the AWS console before launching resources.

## Result

An EC2 virtual server can be created and accessed through AWS.

## Evidence

Add your own screenshots if you performed the experiment:

```text
screenshots/
├── ec2-dashboard.png
├── launch-instance.png
├── instance-running.png
└── connect-to-instance.png
```
