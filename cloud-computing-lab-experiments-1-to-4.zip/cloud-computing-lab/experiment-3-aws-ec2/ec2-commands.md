# EC2 Connection Notes

These are example notes for the lab record. Replace placeholders only with values from your own AWS instance.

## Linux/SSH connection

The AWS console provides an SSH command for the selected instance.

Example form:

```bash
ssh -i "YOUR_KEY.pem" USERNAME@YOUR_PUBLIC_DNS
```

Do not commit the `.pem` file.

## Verification commands

After connecting to a Linux EC2 instance, basic verification can be performed with:

```bash
whoami
uname -a
pwd
ls
```

## Cleanup

After completing the experiment, stop or terminate the instance as appropriate so that unwanted cloud charges are avoided.
