# Cloud Computing and Security Lab

Experiments 1–4 for the Cloud Computing and Security laboratory.

## Experiments

| No. | Experiment | Main Technology |
|---|---|---|
| 1 | Install VirtualBox/VMware Workstation with a Linux/Windows virtual machine | VirtualBox |
| 2 | Install a C compiler in the virtual machine and execute a simple C program | Ubuntu, GCC, C |
| 3 | Create an EC2 instance in AWS | Amazon EC2 |
| 4 | Develop a simple application using Apex | Salesforce |

> **Note:** This repository is a reconstructed lab-work repository based on the supplied Cloud Computing Lab Manual. It contains the code, commands, documentation, and repository structure needed for the experiments. It does not invent personal screenshots, AWS instance IDs, IP addresses, credentials, or execution evidence. Add your own screenshots/results if you have them.

## Course

**CS722I1C – Cloud Computing and Security**  
Department of Computer Science & Engineering  
Sahyadri College of Engineering & Management, Mangaluru

## Repository Structure

```text
cloud-computing-lab/
├── README.md
├── experiment-1-virtualbox/
│   └── README.md
├── experiment-2-c-compiler/
│   ├── README.md
│   └── hello.c
├── experiment-3-aws-ec2/
│   ├── README.md
│   ├── ec2-commands.md
│   └── .gitignore
└── experiment-4-salesforce-apex/
    ├── README.md
    ├── HelloWorldApp.cls
    └── execute-anonymous.apex
```

## Important

Never upload AWS `.pem` private keys, passwords, access tokens, Salesforce credentials, or other secrets to GitHub.
